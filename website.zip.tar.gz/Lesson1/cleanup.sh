#! /bin/bash

rm ~/Music/evil.py
rm ~/Documents/Secrets/dns-exfil.sh
rm ~/Downloads/tools.zip
rm ~/Downloads/HelloWorld.py
launchctl unload -w /Users/janed/Library/LaunchAgents/com.malicious.evil.plist
rm ~/Library/LaunchAgents/com.malicious.evil.plist
rm ~/Downloads/cleanup.sh
